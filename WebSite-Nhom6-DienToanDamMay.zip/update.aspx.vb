﻿
Partial Class update
    Inherits System.Web.UI.Page

End Class
